"""PeSTO base tables and legal Python fallback evaluation.

Odin adds its original fitted positional correction in the native hot path.
The live referee uses a 600-ply draw, never kingless material adjudication.
"""

from __future__ import annotations

from tables_nb import BLACK, N_PIECES, WHITE, iter_bits

# Ronald Friederich PeSTO, as published on Chess Programming Wiki.
# Index 0 = a1. Black uses sq ^ 56.

MG_VALUE = (82, 337, 365, 477, 1025, 0)
EG_VALUE = (94, 281, 297, 512, 936, 0)
PHASE_INC = (0, 1, 1, 2, 4, 0)  # P N B R Q K
TEMPO = 10

# Referee kingless material, in pawn-centipawns so it sits next to PeSTO.
ADJ_VALUE = (100, 300, 300, 500, 900, 0)
DARK_SQUARES = 0xAA55AA55AA55AA55
LIGHT_SQUARES = 0x55AA55AA55AA55AA

MG_PST = (
    (  # pawn
        0,   0,   0,   0,   0,   0,  0,   0,
        98, 134,  61,  95,  68, 126, 34, -11,
        -6,   7,  26,  31,  65,  56, 25, -20,
        -14,  13,   6,  21,  23,  12, 17, -23,
        -27,  -2,  -5,  12,  17,   6, 10, -25,
        -26,  -4,  -4, -10,   3,   3, 33, -12,
        -35,  -1, -20, -23, -15,  24, 38, -22,
        0,   0,   0,   0,   0,   0,  0,   0,
    ),
    (  # knight
        -167, -89, -34, -49,  61, -97, -15, -107,
        -73, -41,  72,  36,  23,  62,   7,  -17,
        -47,  60,  37,  65,  84, 129,  73,   44,
        -9,  17,  19,  53,  37,  69,  18,   22,
        -13,   4,  16,  13,  28,  19,  21,   -8,
        -23,  -9,  12,  10,  19,  17,  25,  -16,
        -29, -53, -12,  -3,  -1,  18, -14,  -19,
        -105, -21, -58, -33, -17, -28, -19,  -23,
    ),
    (  # bishop
        -29,   4, -82, -37, -25, -42,   7,  -8,
        -26,  16, -18, -13,  30,  59,  18, -47,
        -16,  37,  43,  40,  35,  50,  37,  -2,
        -4,   5,  19,  50,  37,  37,   7,  -2,
        -6,  13,  13,  26,  34,  12,  10,   4,
        0,  15,  15,  15,  14,  27,  18,  10,
        4,  15,  16,   0,   7,  21,  33,   1,
        -33,  -3, -14, -21, -13, -12, -39, -21,
    ),
    (  # rook
        32,  42,  32,  51, 63,  9,  31,  43,
        27,  32,  58,  62, 80, 67,  26,  44,
        -5,  19,  26,  36, 17, 45,  61,  16,
        -24, -11,   7,  26, 24, 35,  -8, -20,
        -36, -26, -12,  -1,  9, -7,   6, -23,
        -45, -25, -16, -17,  3,  0,  -5, -33,
        -44, -16, -20,  -9, -1, 11,  -6, -71,
        -19, -13,   1,  17, 16,  7, -37, -26,
    ),
    (  # queen
        -28,   0,  29,  12,  59,  44,  43,  45,
        -24, -39,  -5,   1, -16,  57,  28,  54,
        -13, -17,   7,   8,  29,  56,  47,  57,
        -27, -27, -16, -16,  -1,  17,  -2,   1,
        -9, -26,  -9, -10,  -2,  -4,   3,  -3,
        -14,   2, -11,  -2,  -5,   2,  14,   5,
        -35,  -8,  11,   2,   8,  15,  -3,   1,
        -1, -18,  -9,  10, -15, -25, -31, -50,
    ),
    (  # king
        -65,  23,  16, -15, -56, -34,   2,  13,
        29,  -1, -20,  -7,  -8,  -4, -38, -29,
        -9,  24,   2, -16, -20,   6,  22, -22,
        -17, -20, -12, -27, -30, -25, -14, -36,
        -49,  -1, -27, -39, -46, -44, -33, -51,
        -14, -14, -22, -46, -44, -30, -15, -27,
        1,   7,  -8, -64, -43, -16,   9,   8,
        -15,  36,  12, -54,   8, -28,  24,  14,
    ),
)

EG_PST = (
    (  # pawn
        0,   0,   0,   0,   0,   0,   0,   0,
        178, 173, 158, 134, 147, 132, 165, 187,
        94, 100,  85,  67,  56,  53,  82,  84,
        32,  24,  13,   5,  -2,   4,  17,  17,
        13,   9,  -3,  -7,  -7,  -8,   3,  -1,
        4,   7,  -6,   1,   0,  -5,  -1,  -8,
        13,   8,   8,  10,  13,   0,   2,  -7,
        0,   0,   0,   0,   0,   0,   0,   0,
    ),
    (  # knight
        -58, -38, -13, -28, -31, -27, -63, -99,
        -25,  -8, -25,  -2,  -9, -25, -24, -52,
        -24, -20,  10,   9,  -1,  -9, -19, -41,
        -17,   3,  22,  22,  22,  11,   8, -18,
        -18,  -6,  16,  25,  16,  17,   4, -18,
        -23,  -3,  -1,  15,  10,  -3, -20, -22,
        -42, -20, -10,  -5,  -2, -20, -23, -44,
        -29, -51, -23, -15, -22, -18, -50, -64,
    ),
    (  # bishop
        -14, -21, -11,  -8, -7,  -9, -17, -24,
        -8,  -4,   7, -12, -3, -13,  -4, -14,
        2,  -8,   0,  -1, -2,   6,   0,   4,
        -3,   9,  12,   9, 14,  10,   3,   2,
        -6,   3,  13,  19,  7,  10,  -3,  -9,
        -12,  -3,   8,  10, 13,   3,  -7, -15,
        -14, -18,  -7,  -1,  4,  -9, -15, -27,
        -23,  -9, -23,  -5, -9, -16,  -5, -17,
    ),
    (  # rook
        13, 10, 18, 15, 12,  12,   8,   5,
        11, 13, 13, 11, -3,   3,   8,   3,
        7,  7,  7,  5,  4,  -3,  -5,  -3,
        4,  3, 13,  1,  2,   1,  -1,   2,
        3,  5,  8,  4, -5,  -6,  -8, -11,
        -4,  0, -5, -1, -7, -12,  -8, -16,
        -6, -6,  0,  2, -9,  -9, -11,  -3,
        -9,  2,  3, -1, -5, -13,   4, -20,
    ),
    (  # queen
        -9,  22,  22,  27,  27,  19,  10,  20,
        -17,  20,  32,  41,  58,  25,  30,   0,
        -20,   6,   9,  49,  47,  35,  19,   9,
        3,  22,  24,  45,  57,  40,  57,  36,
        -18,  28,  19,  47,  31,  34,  39,  23,
        -16, -27,  15,   6,   9,  17,  10,   5,
        -22, -23, -30, -16, -16, -23, -36, -32,
        -33, -28, -22, -43,  -5, -32, -20, -41,
    ),
    (  # king
        -74, -35, -18, -18, -11,  15,   4, -17,
        -12,  17,  14,  17,  17,  38,  23,  11,
        10,  17,  23,  15,  20,  45,  44,  13,
        -8,  22,  24,  27,  26,  33,  26,   3,
        -18,  -4,  21,  24,  27,  23,   9, -11,
        -19,  -3,  11,  21,  23,  16,   7,  -9,
        -27, -11,   4,  13,  14,   4,  -5, -17,
        -53, -34, -21, -11, -28, -14, -24, -43,
    ),
)


def _build_tables() -> tuple[list[list[int]], list[list[int]]]:
    # CPW listing is rank-8-first (index 0 = a8). Ours is a1 = 0.
    mg = [[0] * 64 for _ in range(N_PIECES)]
    eg = [[0] * 64 for _ in range(N_PIECES)]
    for pt in range(6):
        for sq in range(64):
            mg[pt][sq] = MG_VALUE[pt] + MG_PST[pt][sq ^ 56]
            eg[pt][sq] = EG_VALUE[pt] + EG_PST[pt][sq ^ 56]
            mg[pt + 6][sq] = MG_VALUE[pt] + MG_PST[pt][sq]
            eg[pt + 6][sq] = EG_VALUE[pt] + EG_PST[pt][sq]
    return mg, eg


MG_TABLE, EG_TABLE = _build_tables()


def pesto(pos, *, tempo: bool = True) -> int:
    """Score from the side to move, centipawns."""
    mg_w = mg_b = eg_w = eg_b = 0
    phase = 0
    for piece in range(6):
        inc = PHASE_INC[piece]
        for sq in iter_bits(pos.bb[piece]):
            mg_w += MG_TABLE[piece][sq]
            eg_w += EG_TABLE[piece][sq]
            phase += inc
        bp = piece + 6
        for sq in iter_bits(pos.bb[bp]):
            mg_b += MG_TABLE[bp][sq]
            eg_b += EG_TABLE[bp][sq]
            phase += inc
    if phase > 24:
        phase = 24
    mg_score = mg_w - mg_b
    eg_score = eg_w - eg_b
    score = (mg_score * phase + eg_score * (24 - phase)) // 24
    if pos.side == BLACK:
        score = -score
    if tempo:
        # Tempo belongs to the side to move.  Adding it before the colour
        # flip accidentally turns it into a White-only bonus.
        score += TEMPO
    return score


def kingless_material(pos) -> int:
    """Referee adjudication, from the side to move, pawn=100."""
    w = b = 0
    for pt in range(5):
        w += pos.bb[pt].bit_count() * ADJ_VALUE[pt]
        b += pos.bb[pt + 6].bit_count() * ADJ_VALUE[pt]
    score = w - b
    if pos.side == BLACK:
        score = -score
    return score


def insufficient_material(pos) -> bool:
    """Match python-chess's conservative material-only dead-position test."""
    if pos.bb[0] | pos.bb[3] | pos.bb[4] | pos.bb[6] | pos.bb[9] | pos.bb[10]:
        return False
    knights = pos.bb[1] | pos.bb[7]
    bishops = pos.bb[2] | pos.bb[8]
    if knights:
        return not bishops and knights.bit_count() == 1
    if bishops:
        return not (bishops & DARK_SQUARES) or not (bishops & LIGHT_SQUARES)
    return True


def evaluate(pos, *, adjudicate: bool = False) -> int:
    return pesto(pos)


# Positional correction is native-only in this experimental candidate.
# A fallback remains legal vanilla PeSTO; release requires native readiness.
